# PAM IN R.
#27 Jan 2014
#By: Rob Johnson, Simon Reeves, Shihong Lee, Emma Flukes.
#
# 
#
#
#-----------------------------------------------------------------------------------------------
#
#
# Step 1 - IMPORT RAW PAM FILE.
rm(list = ls())
library(functional)
setwd("/Users/Rob_MacPro/Documents/3._Current_Projects/emmaPAM")
filename = 'allsitesT3.csv'
data = read.csv(filename, sep = ";",header = FALSE) #pulls out the raw data but creates a stupid list - much like a python dictionary.
dataM = as.matrix(data[names(data)]) #takes the keys for the list and builds a matrix out of the stupid list. The matrix is a char matrix as we have mixed types within a column (eg numbers and letters).

DatePos = which(dataM[2,] == 'Date')
TimePos = which(dataM[2,] == 'Time')
TypePos = which(dataM[2,] == 'Type')
NoPos = which(dataM[2,] == 'No.')
FPos = which(dataM[2,] == '1:F')
FmPos = which(dataM[2,] == "1:Fm'")
PARPos = which(dataM[2,] == '1:PAR')
YieldPos = which(dataM[2,] == '1:Y (II)')
ETRPos = which(dataM[2,] == '1:ETR')

#Next step is to clean up the matrix.
y <- which(dataM[,TypePos] == 'FO')
#create an empty data.frame
goodY = matrix(NA, nrow = length(y), ncol = 1)
for(i in 1:length(y)) {
  if ((y[i]+8) <= nrow(dataM)){
    if (sum(dataM[(y[i]:(y[i]+8)),TypePos] == c("FO", "F", "F", "F", "F", "F", "F", "F", "F")) == 9) {
      goodY[i] = y[i]
    }
  }
}
  
rm(i, y)
Y <- goodY[apply(goodY, 1, Compose(is.finite, all)),]

dataF = data.frame(matrix(NA, nrow = (length(Y)*9), ncol = ncol(dataM)))
colnames(dataF) = c("Date", "Time", "IDX", "MemNo", "F", "Fm", "PAR","Yield", "ETR")

for(i in 1:length(Y)){
  if(i ==1){
    dataF$Date[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),DatePos]
    dataF$Time[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),TimePos]
    dataF$IDX[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),TypePos]
    dataF$MemNo[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),NoPos]
    dataF$F[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),FPos]
    dataF$Fm[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),FmPos]
    dataF$PAR[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),PARPos]
    dataF$Yield[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),YieldPos]
    dataF$ETR[i:(i+8)] <- dataM[(Y[i]:(Y[i]+8)),ETRPos]
  }else{
    dataF$Date[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),DatePos]
    dataF$Time[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),TimePos]
    dataF$IDX[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),TypePos]
    dataF$MemNo[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),NoPos]
    dataF$F[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),FPos]
    dataF$Fm[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),FmPos]
    dataF$PAR[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),PARPos]
    dataF$Yield[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),YieldPos]
    dataF$ETR[(((i-1)*9)+1):(((i-1)*9)+9)] <- dataM[(Y[i]:(Y[i]+8)),ETRPos]
  }
}

df <- dataF[,colSums(is.na(dataF))<nrow(dataF)] #removes any extra columns of NA
dataFIN = na.omit(df) #removes any extra rows of NA
rm(i,Y,goodY,data,dataF,dataM,df, DatePos, TimePos, TypePos, NoPos, FPos, FmPos, PARPos, YieldPos, ETRPos) #cleans up.

#----------------------------------------------------------------------------------
# allow user input for nameing and stuff.
i = nchar(filename, type = "chars", allowNA = FALSE)
paramname = paste(substr(filename,1,i-4), "PARAM.csv", sep="_")
rm(i)
userParameters = read.csv(paramname,header=TRUE)

dataFIN[c(names(userParameters))] <- NA
for(i in 1:(nrow(userParameters))){
  ind = which(dataFIN$MemNo == userParameters$UMemNo[i])
  if(length(ind) != 0){
    for(a in 0:(length(userParameters)-1)){
      for(ii in (ind-8):ind){
        dataFIN[ii,(ncol(dataFIN)-a)] = toString(userParameters[i,(ncol(userParameters)-a)])
      }
    }
  }
}
rm(a,i,ii,ind)


# Do you want to add some other PAR data

#do we have a par file?
i = nchar(filename, type = "chars", allowNA = FALSE)
parname = paste(substr(filename,1,i-4), "PAR.csv", sep="_")
rm(i)
list = list.files()  #creates a list of all the files in teh working directory.
if(sum(list == parname)){
  userPAR = read.csv(parname,header=TRUE)  
}
#dataFIN['newPAR'] <- NA #creates an empty var for the new par.
for(i in seq(1, nrow(userPAR), 9)) {
  ind = which(dataFIN$MemNo == userPAR$UMemNo[i])
  dataFIN$newPAR[(ind-8):ind] = userPAR$PAR[i:(i+8)]
  par = 1
}
rm(i,ind,list)

#recals etr = yield * par
if(par == 1){# if we have used new par values this fills in any missing par values with the default par from the original data set.
  P = as.numeric(dataFIN$newPAR)
  P[which(is.na(dataFIN$newPAR))] = as.numeric(dataFIN$PAR[which(is.na(dataFIN$newPAR))])
}else{
  P = as.numeric(dataFIN$PAR)
}
dataFIN$newETR = as.numeric(dataFIN$Yield) * P


# define platt et al 1980 eqn.
PlattEqn = rETR ~ rETRscal*(1-exp((-A*I)/rETRscal))*exp((-B*I)/rETRscal) #defining the Platt (1980) equation used to fit models to raw RLC data

#extract a light curve to work on.
i = 1 #will need to go up in steps of 9.
#yscale=ceiling(max(dataFIN[i:(i+8),]$newETR)) #pick a starting value 

#dataFIN[i:(i+8),]$newPAR[1] == 0 

A=(dataFIN[i:(i+8),]$newETR[3]/dataFIN[i:(i+8),]$newPAR[3])
start=c(rETRscal=max(dataFIN[i:(i+8),]$newETR))
B=((lv1[8]-lv1[9])/(I[9]-I[8])))

Platt = nls(PlattEqn, start, A, B, control=nls.control(minFactor = 0, warnOnly=TRUE))

#testing convergence... there has to be a better way to do this and to get a confidence/fit value out of the nls object.
#convtester1 = grep("isConv = TRUE",toString(PlattLevel1)) #testing whether convergence ocurs (as we have supressed errors to prevent loop from breaking)







