#******Script for PhD work!******
#Written by Emma Flukes, last modified 14th August 2013

#The following script is set up to work with two "variables". In this case, we have light- and dark-adapted curves from a set of 10 plants.
#The script generates a single PDF file showing rETRmax~PAR plots of raw data from each of the 10 plants, with Platt model fit overlaid across raw data. Each plot shows light- and dark-adapted data. Parameters from

#Input file uses the following column names: 'PAR', 'rETR', 'PlantNo' and 'CurveType'. The column 'CurveType' is for "light" or "dark". This column can be replaced with any two-factor variable.

rm(list=ls()) #clear any stored lists

#read in data
d1 = read.csv("TAS_EckSh_Aug12.csv")
d1[d1 =="."] = NA
d2 = na.omit(d1) #recode data to omit NA values    

I = d2$PAR[1:9]   #accesses PAR and recodes as I
rETR = d2$rETR   #accesses rETR
plant_no = d2$PlantNo  #accesses the plant number (1-10)
curve_type = d2$CurveType  #accesses the CURVE TYPE column - this will be light or dark

#Defining objects and matrices used later in FOR LOOP
numplants = max(plant_no) #specifies the number of plants sampled

#Sets up correctly labelled blank matrix into which Equation-derived parameters are written via the for loop below
generic = matrix(NA,ncol=8,nrow=numplants)
rownames(generic) = c("P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10") #Plants 1 to 10. This really should be automated. You will need to manually enter your plant/sample IDs here
colnames(generic) = c("Curve Type", "rETRmax", "Alpha", "Beta", "Im", "Ik", "Ib", "rETRscaler")
generic[,1] = "Light"
lv1_params=generic;
generic[,1] = "Dark"
lv2_params=generic;

PlattEqn1 = lv1 ~ rETRscal*(1-exp((-A*I)/rETRscal))*exp((-B*I)/rETRscal) #defining the Platt (1980) equation used to fit models to raw RLC data
PlattEqn2 = lv2 ~ rETRscal*(1-exp((-A*I)/rETRscal))*exp((-B*I)/rETRscal) #defining the Platt (1980) equation used to fit models to raw RLC data



#Setting up PDF output for graphs that will be plotted within FOR LOOP
pdf('rETR_curves.pdf',width=8, height=12,pointsize=12, paper='special') #change width and height of graphs if you don't like current settings
par(mfrow=c(4,3)) #specifies number of plots per row and column, in format (row,column)

for(i in 1:numplants) {

#Defines the subset of data to look at, e.g. rETR for OLD tissue of PLANT 7
lv1 = d2[curve_type=="light" & plant_no==i, "rETR"]
lv2 = d2[curve_type=="dark" & plant_no==i, "rETR"]

#Calculate max. value for graph axis
yscale=ceiling(max(d2$rETR))

#Plotting of raw data. This only needs to be a simple command (see top block of 'plot', 'points' and 'legend' commands) but all the IF and ELSE statements are built in to handle NA in data set and ensure loop doesn't break
dummy=c(length(lv1),length(lv2)) #dummy vector set up to test whether data subset (plant/factor combo) is OK to plot
if(sum(dummy)==18) {plot(I,lv1, main=paste('Plant no.', i), xlab=expression ("Irradiance, �mol photons"~m^{2}~s^{-1}),  #if we have OKAY DATA, THEN...
                      ylab="rETR",pch=1,cex=1.5,ylim=c(0,yscale))
                      points(I, lv2,pch=16,cex=1.5)
                      legend("bottomright", title="Curve type", c("Light","Dark"), pch=c(1,16),xjust=0)} else
if(sum(dummy)==9 && dummy[1]==9) {plot(I,lv1, main=paste('Plant no.', i), xlab=expression ("Irradiance, �mol photons"~m^{2}~s^{-1}),   #if we only have LIGHT data, don't plot the dark data!
                      ylab="rETR",pch=1,cex=1.5,ylim=c(0,yscale))
                      legend("bottomright", title="Curve type", c("Light"), pch=c(1),xjust=0)} else
if(sum(dummy)==9 && dummy[2]==9) {plot(I,lv2, main=paste('Plant no.', i), xlab=expression ("Irradiance, �mol photons"~m^{2}~s^{-1}),    #if we only have DARK data, don't plot the light data!
                      ylab="rETR",pch=16,cex=1.5,ylim=c(0,yscale))
                      legend("bottomright", title="Curve type", c("Dark"), pch=c(16),xjust=0)} 			




					  
					  #NLS FITTING steps of Platt et al 1980
convtester1 = c(0,0)
convtester2 = c(0,0)				  
					  
if (dummy[1]==9) { #IF data exists for light curves, plant no. i, then...
PlattLevel1 = nls(PlattEqn1, start=c(rETRscal=max(lv1), A=(lv1[3]/I[3]), B=((lv1[8]-lv1[9])/(I[9]-I[8]))), control=nls.control(minFactor = 0, warnOnly=TRUE))
convtester1 = grep("isConv = TRUE",toString(PlattLevel1)) #testing whether convergence ocurs (as we have supressed errors to prevent loop from breaking)
}
if (dummy[2]==9) { #IF data exists for dark curves, plant no. i, then...
PlattLevel2 = nls(PlattEqn2, start=c(rETRscal=max(lv2), A=(lv2[3]/I[3]), B=((lv2[8]-lv2[9])/(I[9]-I[8]))), control=nls.control(minFactor = 0, warnOnly=TRUE))    
convtester2 = grep("isConv = TRUE",toString(PlattLevel2))
}

if (length(convtester1)==1)  {	#if convergence HAS been achieved, do the stuff below (otherwise do nothing)
	pars2<- as.list(coef(PlattLevel1))     
	with(pars2,curve(rETRscal*(1-exp((-A*x)/rETRscal))*exp((-B*x)/rETRscal), add=TRUE, lty=2, lwd=1))}

if (length(convtester2)==1) {	
	pars2<- as.list(coef(PlattLevel2))  
		with(pars2,curve(rETRscal*(1-exp((-A*x)/rETRscal))*exp((-B*x)/rETRscal), add=TRUE, lty=2, lwd=1))}
     
statlist=list(); variable_params = list() #Defining lists used in extracting model parameters
options(warn=-1) #Turning off warning messages that you don't need to worry about

for (j in 1:3) {                                       #Loop repeats 1:3 to write rETRscal, A & B
if (length(convtester1)!=1) {LIGHT = 'nil'} else	#if convergence HASN'T been achieved, write 'nil' in our output matrix, otherwise spit out some parameters
        LIGHT = summary(PlattLevel1)$"parameters"[j,1] #Level 1 (light curves) parameters from model output
if (length(convtester2)!=1) {DARK = 'nil'} else
        DARK = summary(PlattLevel2)$"parameters"[j,1] #Level 2 (dark curves) parameters from model output
    statlist[[j]]=as.numeric(c(LIGHT,DARK))
  }

Z = matrix(c(statlist[[1]], statlist[[2]], statlist[[3]]), ncol=3, byrow=FALSE)       #*************NCOL MAYBE NEEDS TO BE 3
      
#Calculating rETRmax, Im, Ik, Ib, Alpha and Beta from model parameter outputs. These equations come from original Platt et al (1980) paper
for (k in 1:2) {
if (length(convtester1)!=1 && k==1) {variable_params[[k]] = rep(NA, 7);  next} else
if (length(convtester2)!=1 && k==2) {variable_params[[k]] = rep(NA, 7); next} else
        rETRmax = Z[k,1]*Z[k,2]/(Z[k,2]+Z[k,3])*(Z[k,3]/(Z[k,2]+Z[k,3]))^(Z[k,3]/Z[k,2])
        Imm = Z[k,1]/Z[k,2]*log((Z[k,2]+Z[k,3])/Z[k,3], exp(1))      #"Im" called "Imm" so as not to clash with inbuilt function
        Ik = Z[k,1]/Z[k,2]
        Ib = Z[k,1]/Z[k,3]                                            
        Alpha = Z[k,2]
        Betaa = Z[k,3]                                              #"Beta" called "Betaa" so as not to clash with inbuilt function
        rETRscaler = Z[k,1]
    variable_params[[k]]=c(rETRmax, Alpha, Betaa, Imm, Ik, Ib, rETRscaler)
  }

#Writing final parameters to dynamic matrices
lv1_params[i,2:8] = matrix(c(variable_params[[1]]),ncol=7,byrow=TRUE)
lv2_params[i,2:8] = matrix(c(variable_params[[2]]),ncol=7,byrow=TRUE)
        
}
dev.off() 
    
	
alldata = noquote(rbind(lv1_params, lv2_params))
																					
####Do you want to write your raw parameter outputs to an Excel file? If so, run this bunch of code where Level1 = stipe or morning sampling, Level2 = new tissue or midday sampling, Level3 = old tissue or afternoon sampling
write.csv(alldata, file="PAM_derived_parameters.csv",append=FALSE,quote=FALSE,sep="  ",na=".",col.names=TRUE)