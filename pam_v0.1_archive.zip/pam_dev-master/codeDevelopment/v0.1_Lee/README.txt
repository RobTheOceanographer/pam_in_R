Instructions for Dr.Lee...


- Go to the folder 'v0.1_Lee'
- Open 'PAMELA_v0.1.R' in RStudio
- Change the 'setwd(______)' to be your working directory (This is where your data are)
- Change the 'filename = '_________'' to be the name of the file you wish to work on.
- save the code.
- click 'Run' in RStudio.
- The code should now loop through all of your Light Curves and ask you for help with the ones it gets stuck on. The data will be automatically saved and the plots will be saved in a folder called 'plots'. 
- Repeat until dead.

########
By Rob Johnson, on 19 April 2014.
robtheoceanographer@gmail.com
########