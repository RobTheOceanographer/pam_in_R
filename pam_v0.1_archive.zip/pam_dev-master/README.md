WELCOME TO THE WONDERFUL WORLD OF PAM!
This program is brought to you by Rob Johnson, Shihong Lee, Simon Reeves, and Emma Flukes. We are PhD students at the University of Tasmania and we were fed up with the ridiculous amount of time it was taking to analyse PAM Rapid Light Curves using clunky and expensive stats software (copy... paste... copy... paste... SPSS... boooo!). So, we build the PAM Processor! using the free and open stats scripting language R and the web application tool Shiny.

At the moment the PAM Processor! v0.1 is only set up for Micro-Algae and can NOT calculate Beta - it basically ignores photoinhibition. We are working on bringing you this, and many more, features in the near future.

2014 Robert Johnson, Shihong Lee, Simon Reeves, and Emma Flukes.

Feedback is appreciated:
Robert Johnson's homepage  http://www.robtheoceanographer.com
Email robtheoceanographer@gmail.com
                                          